"""
=============================================================
chatbot/agent.py — הלוגיקה המרכזית של הצ'אטבוט
=============================================================

מטרה:
    מנהל את מחזור חיי השיחה כולו: מקבל הודעת משתמש,
    מנתב לשלב המתאים, מבצע אימות זהות, שולף נתונים אמיתיים,
    ומחזיר תשובה בעברית.

ארכיטקטורה (State Machine):
    כל הודעת משתמש עוברת דרך process_message() →
    מנותבת לפי state.stage → מחזירה תשובה טקסטואלית.

    GREETING → IDENTIFY → VERIFY → ANSWERED
                        → CLARIFY (אם שם לא ייחודי)
                                  → BLOCKED (אחרי 3 כשלונות)

    כל שלב יכול לעבור ל-RAG_MODE לשאלות כלליות.

שינוי ל-PythonAnywhere:
    במקום HTTP requests ל-localhost:8000 (FastAPI),
    משתמשים ב-db_service.py שפונה ישירות ל-SQLite.
    זה מאפשר הפעלה כתהליך יחיד ב-PythonAnywhere.

כלל אבטחה קשיח:
    לפני stage=ANSWERED, אסור בתכלית האיסור
    להחזיר תאריך, שעה, או כל פרט על תור.
    הקוד בודק זאת ב-_deliver_answer() לפני כל שליפה.

5 תרחישי בדיקה נתמכים:
    1. שם ייחודי + תאריך שגוי → תיקון
    2. שם לא ייחודי → הבהרה
    3. ת.ז. שגויה (עד 3 פעמים) → חסימה
    4. לקוח ללא תורים → הודעה מתאימה
    5. שם לא קיים → הודעה מתאימה
"""

import re
from chatbot.state import ConversationState, MAX_AUTH_ATTEMPTS
from chatbot.nlu import extract_intent, generate_response
from chatbot import db_service


# ===========================================================
# הודעות קבועות (Hardcoded messages)
# ===========================================================
# הודעות אלו אינן עוברות דרך Gemini — הן תמיד זהות ומאובטחות

MSG_GREETING = (
    "שלום! אני הבוט של FitStudio 🏋️\n"
    "אני יכול לעזור לך לבדוק פרטי תור, שעות הסטודיו ועוד.\n"
    "ספר לי — מה שמך ומה תרצה לדעת?"
)

MSG_ASK_NAME = "מה שמך? (יש להזין שם פרטי לפחות)"

def MSG_NOT_FOUND(name: str) -> str:
    """הודעה כאשר שם לא נמצא כלל בבסיס הנתונים."""
    return (
        f"לא מצאתי מנוי בשם \"{name}\" במערכת.\n"
        "ייתכן שהשם אינו תואם בדיוק. נסה שם אחר, או פנה אלינו ישירות."
    )

def MSG_CLARIFY(candidates: list) -> str:
    """
    הודעה כשנמצאו כמה מנויים עם שם דומה.
    מציגה שם + 4 ספרות אחרונות של טלפון (פרטיות).
    """
    lines = "\n".join(
        f"  {i+1}. {c['name']} (טל' ...{c['phone'][-4:]})"
        for i, c in enumerate(candidates)
    )
    return f"מצאתי כמה מנויים עם שם דומה:\n{lines}\nאנא ציין שם מלא (שם פרטי + שם משפחה)."

def MSG_ASK_ID(name: str, attempts_left: int) -> str:
    """
    בקשה להזנת תעודת זהות לאימות.
    מציין כמה ניסיונות נותרו.
    """
    return (
        f"זיהיתי אותך כ-{name}. 🔐\n"
        f"לאימות זהות, אנא הזן את מספר תעודת הזהות שלך.\n"
        f"(נותרו {attempts_left} ניסיונות)"
    )

def MSG_WRONG_ID(attempts_left: int) -> str:
    """הודעה כשתעודת הזהות שגויה — לא חושפת שום פרט."""
    if attempts_left == 1:
        warning = "⚠️ נותר ניסיון אחד בלבד!"
    else:
        warning = f"נותרו {attempts_left} ניסיונות."
    return f"תעודת הזהות שגויה. אנא נסה שנית.\n{warning}"

MSG_BLOCKED = (
    "חרגת ממגבלת ניסיונות האימות המותרת (3 ניסיונות). 🔒\n"
    "לביטחון פרטיך, השיחה נחסמת.\n"
    "אנא פנה אלינו ישירות לסיוע.\n"
    "📞 טלפון: 050-0000000"
)

MSG_RESET = "✅ השיחה אופסה. שלום! כיצד אוכל לעזור?"

MSG_FALLBACK = (
    "לא מצאתי מידע ספציפי על שאלתך.\n"
    "אנא פנה אלינו ישירות:\n"
    "📞 טלפון: 050-0000000\n"
    "🏠 כתובת: רחוב הספורט 1, תל אביב"
)


# ===========================================================
# ChatbotAgent — מחלקה ראשית
# ===========================================================

class ChatbotAgent:
    """
    מנהל שיחה עם משתמש מקצה לקצה.

    יצירת instance:
        agent = ChatbotAgent()

    שימוש בכל הודעה:
        response = agent.process_message("קוראים לי רותם...")

    שמירה בין הודעות:
        ב-Streamlit: st.session_state["agent"] = agent
        ב-Flask:     session["agent_state"] = pickle.dumps(agent)

    Attributes:
        state: ConversationState — מחזיק את כל מצב השיחה
    """

    def __init__(self):
        """אתחול סוכן עם מצב שיחה חדש (GREETING)."""
        self.state = ConversationState()

    # ------------------------------------------------------------------
    # ← נקודת הכניסה הציבורית היחידה ←
    # ------------------------------------------------------------------

    def process_message(self, user_message: str) -> str:
        """
        מעבד הודעת משתמש ומחזיר תשובת בוט.

        זהו ה-entry point היחיד שצריך לקרוא מבחוץ.
        כל לוגיקת הניתוב מתרחשת כאן.

        תהליך:
            1. בדוק אם שיחה חסומה (BLOCKED)
            2. חלץ intent בעזרת Gemini NLU
            3. בדוק בקשת איפוס
            4. נתב ל-handler המתאים לפי stage
            5. הוסף הודעות להיסטוריה

        Args:
            user_message: טקסט חופשי בעברית מהמשתמש

        Returns:
            תשובת הבוט כטקסט (עברית)
        """
        user_message = user_message.strip()

        # שמור את הודעת המשתמש בהיסטוריה
        self.state.add_message("user", user_message)

        # ---- בדיקה: שיחה חסומה לאחר 3 כישלונות ----
        if self.state.is_blocked:
            self.state.add_message("bot", MSG_BLOCKED)
            return MSG_BLOCKED

        # ---- NLU: חילוץ intent ומידע מובנה ----
        nlu = extract_intent(user_message)
        intent = nlu.get("intent", "OTHER")

        # ---- איפוס מפורש של השיחה ----
        reset_keywords = {"התחל מחדש", "חדש", "reset", "restart", "נתחיל מחדש"}
        if intent == "RESET" or user_message.strip().lower() in reset_keywords:
            self.state.reset()
            self.state.add_message("bot", MSG_RESET)
            return MSG_RESET

        # ---- ניתוב לפי שלב השיחה ----
        response = self._route(intent, nlu, user_message)
        self.state.add_message("bot", response)
        return response

    # ------------------------------------------------------------------
    # ניתוב (Router)
    # ------------------------------------------------------------------

    def _route(self, intent: str, nlu: dict, raw: str) -> str:
        """
        מנתב את ההודעה ל-handler המתאים לפי stage נוכחי.

        Args:
            intent: כוונת המשתמש (מ-NLU)
            nlu   : dict מלא של תוצאת NLU (שם, תאריך, ת.ז. וכו')
            raw   : הטקסט הגולמי של המשתמש

        Returns:
            תשובת הבוט
        """
        stage = self.state.stage

        if stage == "GREETING":
            # ברכה ראשונה — עובר ל-IDENTIFY מייד
            self.state.stage = "IDENTIFY"
            if intent == "GREETING":
                return MSG_GREETING
            # אם הזין שם מייד ללא ברכה — המשך לזיהוי
            return self._handle_identify(intent, nlu, raw)

        elif stage == "IDENTIFY":
            return self._handle_identify(intent, nlu, raw)

        elif stage == "CLARIFY":
            return self._handle_clarify(nlu, raw)

        elif stage == "VERIFY":
            return self._handle_verify(intent, nlu, raw)

        elif stage == "ANSWERED":
            return self._handle_answered(intent, nlu, raw)

        elif stage == "RAG_MODE":
            return self._handle_rag(raw)

        return "מצטערים, אירעה שגיאה פנימית. נסה שוב."

    # ------------------------------------------------------------------
    # Handlers — handler לכל שלב שיחה
    # ------------------------------------------------------------------

    def _handle_identify(self, intent: str, nlu: dict, raw: str) -> str:
        """
        שלב IDENTIFY: חיפוש לקוח לפי שם.

        תרחישים:
            - שאלה כללית → RAG_MODE
            - שם נמסר, לא נמצא → הודעת "לא קיים"
            - שם נמסר, תוצאה ייחודית → VERIFY (מבקש ת.ז.)
            - שם נמסר, כמה תוצאות → CLARIFY (מבקש הבהרה)
            - לא נמסר שם → בקשה לספק שם

        Args:
            intent: כוונת המשתמש
            nlu   : מידע מחולץ (name, claimed_date וכו')
            raw   : הטקסט הגולמי
        """
        # שאלה כללית (שעות, מחירים) → עבור ל-RAG
        if intent == "GENERAL_QUESTION":
            self.state.stage = "RAG_MODE"
            return self._handle_rag(raw)

        name = nlu.get("name")

        # שמור תביעות תאריך/שעה אם הוזנו יחד עם השם
        if nlu.get("claimed_date"):
            self.state.claimed_date = nlu["claimed_date"]
        if nlu.get("claimed_time"):
            self.state.claimed_time = nlu["claimed_time"]

        if not name:
            # לא נמצא שם בהודעה — בקש שוב
            return MSG_ASK_NAME

        # ---- חיפוש ישיר בבסיס הנתונים ----
        result = db_service.search_members(name)
        count = result.get("count", 0)
        candidates = result.get("results", [])

        if count == 0:
            # תרחיש 5: שם לא קיים כלל במערכת
            return generate_response("not_found", {"name": name})

        if count == 1:
            # מנוי ייחודי — עבור לשלב אימות
            m = candidates[0]
            self.state.candidate_member_id = m["id"]
            self.state.candidate_member_name = m["name"]
            self.state.stage = "VERIFY"
            return MSG_ASK_ID(m["name"], self.state.attempts_left)

        # תרחיש 2: כמה מנויים עם שם דומה → הבהרה
        self.state.multiple_candidates = candidates
        self.state.stage = "CLARIFY"
        return MSG_CLARIFY(candidates)

    def _handle_clarify(self, nlu: dict, raw: str) -> str:
        """
        שלב CLARIFY: בחירה מבין מספר מנויים עם שם דומה.

        הלוגיקה:
            מנסה להתאים את הטקסט שהמשתמש הזין
            לאחד מן המועמדים ברשימה (substring match).
            אם נמצאה התאמה → עבור ל-VERIFY.
            אם לא → בקש שוב.

        Args:
            nlu: מידע מחולץ (שם מלא אם הוזן)
            raw: הטקסט הגולמי של המשתמש
        """
        # נסה לחלץ שם מה-NLU, אחרת השתמש בטקסט הגולמי
        name_input = nlu.get("name") or raw.strip()

        for candidate in self.state.multiple_candidates:
            candidate_name = candidate["name"]
            # בדיקה גמישה: האם הקלט מופיע בשם המלא או ההפך
            if name_input.strip() in candidate_name or candidate_name in name_input.strip():
                # נמצאה התאמה — עבור לאימות
                self.state.candidate_member_id = candidate["id"]
                self.state.candidate_member_name = candidate_name
                self.state.multiple_candidates = []  # נקה רשימת מועמדים
                self.state.stage = "VERIFY"
                return MSG_ASK_ID(candidate_name, self.state.attempts_left)

        # לא הצלחנו להתאים — בקש שוב עם הרשימה
        return (
            "לא הצלחתי להתאים את השם שציינת. אנא ציין שם מלא (שם פרטי + משפחה):\n"
            + "\n".join(f"  - {c['name']}" for c in self.state.multiple_candidates)
        )

    def _handle_verify(self, intent: str, nlu: dict, raw: str) -> str:
        """
        שלב VERIFY: אימות תעודת זהות.

        אבטחה: תרחיש 3 — לאחר 3 כשלונות → BLOCKED.
        לפני אימות מוצלח: אסור לחשוף כל מידע על תור.

        תהליך:
            1. נסה לחלץ ת.ז. מ-NLU
            2. אם לא נמצא → נסה regex על הטקסט הגולמי
            3. שלח ל-db_service.verify_member_identity()
            4. אם הצליח → ANSWERED → שלוף תור אמיתי
            5. אם נכשל → הגדל מונה → BLOCKED אם חצה גבול

        Args:
            intent: כוונת המשתמש (IDENTITY_RESPONSE נפוץ כאן)
            nlu   : מידע מחולץ (id_number אם זוהה)
            raw   : הטקסט הגולמי
        """
        # שאלה כללית בזמן ממתינים לת.ז. → RAG
        if intent == "GENERAL_QUESTION":
            self.state.stage = "RAG_MODE"
            return self._handle_rag(raw)

        # חילוץ ת.ז.: קודם מ-NLU, אחר כך regex על הטקסט הגולמי
        id_number = nlu.get("id_number")
        if not id_number:
            # regex: חפש רצף של 7-9 ספרות (פורמט ת.ז. ישראלית)
            match = re.search(r'\b\d{7,9}\b', raw)
            if match:
                id_number = match.group()

        if not id_number:
            # לא הוזנה ת.ז. — בקש שוב
            return (
                "אנא הזן מספר תעודת זהות (7-9 ספרות).\n"
                f"נותרו {self.state.attempts_left} ניסיונות."
            )

        # ---- אימות מול בסיס הנתונים ----
        self.state.auth_attempts += 1  # הגדל מונה לפני הבדיקה
        result = db_service.verify_member_identity(
            self.state.candidate_member_id, id_number
        )

        if result.get("verified"):
            # ✅ אימות הצליח!
            self.state.verified = True
            self.state.stage = "ANSWERED"
            return self._deliver_answer()  # שלוף ומסור תור אמיתי

        # ❌ אימות נכשל
        if self.state.auth_attempts >= MAX_AUTH_ATTEMPTS:
            # תרחיש 3: חצה גבול → חסום
            self.state.stage = "BLOCKED"
            return MSG_BLOCKED

        return MSG_WRONG_ID(self.state.attempts_left)

    def _handle_answered(self, intent: str, nlu: dict, raw: str) -> str:
        """
        שלב ANSWERED: המשתמש אומת בהצלחה.

        בשלב זה מותר לחשוף מידע על תורים.
        ממשיך לענות על שאלות חוזרות.

        Args:
            intent: כוונת המשתמש בשאלה הנוכחית
            nlu   : מידע מחולץ (תאריך חדש אם שאל שוב)
            raw   : הטקסט הגולמי
        """
        # שאלה כללית → RAG
        if intent == "GENERAL_QUESTION":
            return self._handle_rag(raw)

        # שאלה חוזרת על תור עם תאריך אחר
        if nlu.get("claimed_date"):
            self.state.claimed_date = nlu["claimed_date"]
            return self._deliver_answer()

        return (
            "✅ אתה מאומת! כיצד אוכל עוד לעזור לך?\n"
            "(לשיחה חדשה, כתוב 'התחל מחדש')"
        )

    def _deliver_answer(self) -> str:
        """
        לב התרחיש המרכזי: שולף תור אמיתי ומשווה לתביעת המשתמש.

        ⚠️ נקרא רק לאחר אימות מוצלח (stage=ANSWERED, verified=True).

        תהליך:
            1. שלוף תורים של המנוי מ-db_service
            2. אם אין תורים → תרחיש 4
            3. קח את התור הקרוב ביותר (ראשון ברשימה)
            4. השווה לתאריך שהמשתמש טען
            5. אם שונה → תרחיש 1: תיקון עם הנכון
            6. אם זהה → אישור

        Returns:
            תשובה טבעית בעברית (דרך Gemini)
        """
        appts_data = db_service.get_member_appointments(self.state.candidate_member_id)
        appointments = appts_data.get("appointments", [])
        name = self.state.candidate_member_name

        if not appointments:
            # תרחיש 4: לקוח ללא תורים פעילים
            return generate_response("no_appointments", {"name": name})

        # לוקחים את התור הראשון (הסדר הוא DESC — הכי קרוב קודם)
        next_appt = appointments[0]
        real_date = next_appt["class_date"]
        real_time = next_appt["start_time"]
        claimed_date = self.state.claimed_date

        if claimed_date and claimed_date != real_date:
            # תרחיש 1: המשתמש טעה בתאריך! → תיקון
            return generate_response(
                "appointment_correction",
                {
                    "name": name,
                    "claimed_date": claimed_date,
                    "real_date": real_date,
                    "real_time": real_time,
                },
            )
        else:
            # התאריך נכון (או לא הוזן תאריך) → אישור
            return generate_response(
                "appointment_correct",
                {
                    "name": name,
                    "claimed_date": claimed_date or real_date,
                    "real_date": real_date,
                    "real_time": real_time,
                },
            )

    def _handle_rag(self, query: str) -> str:
        """
        RAG_MODE: חיפוש תשובה לשאלה כללית ב-ChromaDB.

        תהליך (3 שכבות Fallback):
            1. ניסיון חיפוש ב-ChromaDB (similarity search)
            2. אם נמצאה תשובה רלוונטית → נסח עם Gemini
            3. אם לא נמצא (distance גבוה) → Graceful Fallback

        Lazy import:
            ה-import של rag.retriever נמצא כאן (ולא בראש הקובץ)
            כדי למנוע circular imports ולאפשר טעינה מהירה יותר.

        Args:
            query: שאלת המשתמש

        Returns:
            תשובה טבעית או הודעת Fallback
        """
        try:
            from rag.retriever import get_relevant_answer
            answer = get_relevant_answer(query)
            if answer:
                # נמצאה תשובה רלוונטית — נסח טבעית עם Gemini
                return generate_response(
                    "general_answer",
                    {"question": query, "answer": answer},
                )
        except Exception:
            pass  # כשל ב-ChromaDB → fallback

        # Graceful Fallback: לא נמצא → הפנה לסטודיו
        return MSG_FALLBACK

    # ------------------------------------------------------------------
    # Property נוחות
    # ------------------------------------------------------------------

    @property
    def history(self) -> list:
        """מחזיר את היסטוריית השיחה לתצוגה."""
        return self.state.history
